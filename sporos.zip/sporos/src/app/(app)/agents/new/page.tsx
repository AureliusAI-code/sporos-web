"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useForm, Controller } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { motion } from "framer-motion";
import { Bot, Wrench, Brain, Settings2, Check, Sparkles } from "lucide-react";
import { agentSchema, type AgentForm } from "@/lib/validation/schemas";
import { useCreateAgent, useSkills, useGateways } from "@/lib/hooks/use-hermes";
import { SectionHeading } from "@/components/shared/section-heading";
import { StatusBadge } from "@/components/shared/status-badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { cn, slugify } from "@/lib/utils";

const MODELS = ["gpt-4o", "gpt-4o-mini", "claude-3-5-sonnet", "claude-3-5-haiku", "mistral-large", "llama-3.1-70b"];

function FieldError({ msg }: { msg?: string }) {
  return msg ? <p className="mono mt-1 text-xs text-destructive">{msg}</p> : null;
}

export default function AgentBuilderPage() {
  const router = useRouter();
  const skills = useSkills();
  const gateways = useGateways();
  const createAgent = useCreateAgent();
  const [selectedTools, setSelectedTools] = useState<string[]>([]);

  const {
    register, handleSubmit, control, watch, setValue, formState: { errors },
  } = useForm<AgentForm>({
    resolver: zodResolver(agentSchema),
    defaultValues: {
      name: "", description: "", instructions: "", model: "gpt-4o", temperature: 0.5,
      tools: [], memory: { type: "buffer", window: 12 }, gatewayId: undefined,
    },
  });

  const values = watch();
  const memoryType = watch("memory.type");

  const toggleTool = (id: string) => {
    const next = selectedTools.includes(id) ? selectedTools.filter((t) => t !== id) : [...selectedTools, id];
    setSelectedTools(next);
    setValue("tools", next);
  };

  const onSubmit = async (data: AgentForm) => {
    const agent = await createAgent.mutateAsync({ ...data, gatewayId: data.gatewayId || undefined });
    router.push(`/deployments?agent=${agent.id}`);
  };

  return (
    <div className="space-y-8">
      <SectionHeading
        eyebrow="Agent Builder"
        title="Forge a new agent"
        description="Describe behaviour in natural language; tune configuration, memory, and tools."
      />

      <form onSubmit={handleSubmit(onSubmit)} className="grid gap-6 lg:grid-cols-[1.4fr_1fr]">
        <div className="space-y-6">
          {/* Definition */}
          <Card>
            <CardHeader className="flex-row items-center gap-2 space-y-0">
              <Bot className="h-4 w-4 text-primary" /><CardTitle className="text-base">Definition</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="name">Name</Label>
                <Input id="name" placeholder="Research Analyst" {...register("name")} className="mt-1.5" />
                <FieldError msg={errors.name?.message} />
              </div>
              <div>
                <Label htmlFor="description">Description</Label>
                <Input id="description" placeholder="Synthesises cited research briefings" {...register("description")} className="mt-1.5" />
                <FieldError msg={errors.description?.message} />
              </div>
              <div>
                <Label htmlFor="instructions">Instructions (natural language)</Label>
                <Textarea
                  id="instructions"
                  rows={4}
                  placeholder="You are a meticulous research analyst. Always cite primary sources and flag uncertainty…"
                  {...register("instructions")}
                  className="mt-1.5"
                />
                <FieldError msg={errors.instructions?.message} />
              </div>
            </CardContent>
          </Card>

          {/* Configuration */}
          <Card>
            <CardHeader className="flex-row items-center gap-2 space-y-0">
              <Settings2 className="h-4 w-4 text-primary" /><CardTitle className="text-base">Configuration</CardTitle>
            </CardHeader>
            <CardContent className="grid gap-4 sm:grid-cols-2">
              <div>
                <Label>Model</Label>
                <Controller
                  control={control}
                  name="model"
                  render={({ field }) => (
                    <Select value={field.value} onValueChange={field.onChange}>
                      <SelectTrigger className="mt-1.5"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        {MODELS.map((m) => <SelectItem key={m} value={m}>{m}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  )}
                />
              </div>
              <div>
                <Label>Gateway</Label>
                <Controller
                  control={control}
                  name="gatewayId"
                  render={({ field }) => (
                    <Select value={field.value ?? ""} onValueChange={field.onChange}>
                      <SelectTrigger className="mt-1.5"><SelectValue placeholder="Default" /></SelectTrigger>
                      <SelectContent>
                        {gateways.data?.map((g) => <SelectItem key={g.id} value={g.id}>{g.name}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  )}
                />
              </div>
              <div className="sm:col-span-2">
                <div className="flex items-center justify-between">
                  <Label>Temperature</Label>
                  <span className="mono text-sm text-primary">{Number(values.temperature).toFixed(2)}</span>
                </div>
                <input
                  type="range" min={0} max={2} step={0.05}
                  {...register("temperature")}
                  className="mt-3 w-full accent-[hsl(var(--primary))]"
                />
                <div className="mono mt-1 flex justify-between text-[10px] text-muted-foreground">
                  <span>precise</span><span>balanced</span><span>creative</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Memory */}
          <Card>
            <CardHeader className="flex-row items-center gap-2 space-y-0">
              <Brain className="h-4 w-4 text-primary" /><CardTitle className="text-base">Memory</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Controller
                control={control}
                name="memory.type"
                render={({ field }) => (
                  <div className="grid grid-cols-3 gap-2">
                    {(["ephemeral", "buffer", "vector"] as const).map((t) => (
                      <button
                        key={t}
                        type="button"
                        onClick={() => field.onChange(t)}
                        className={cn(
                          "rounded-md border p-3 text-left text-sm capitalize transition-all",
                          field.value === t ? "border-primary bg-primary/10 text-foreground" : "border-border text-muted-foreground hover:border-border/80"
                        )}
                      >
                        {t}
                      </button>
                    ))}
                  </div>
                )}
              />
              {memoryType === "buffer" && (
                <div>
                  <Label>Window (turns)</Label>
                  <Input type="number" {...register("memory.window")} className="mt-1.5" />
                </div>
              )}
              {memoryType === "vector" && (
                <div className="grid gap-4 sm:grid-cols-2">
                  <div>
                    <Label>Vector store</Label>
                    <Input placeholder="pgvector" {...register("memory.vectorStore")} className="mt-1.5" />
                  </div>
                  <div>
                    <Label>Embed model</Label>
                    <Input placeholder="text-embedding-3-small" {...register("memory.embedModel")} className="mt-1.5" />
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Tools */}
          <Card>
            <CardHeader className="flex-row items-center gap-2 space-y-0">
              <Wrench className="h-4 w-4 text-primary" /><CardTitle className="text-base">Tools</CardTitle>
            </CardHeader>
            <CardContent>
              {skills.isLoading ? (
                <div className="grid gap-2 sm:grid-cols-2">
                  {Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-14" />)}
                </div>
              ) : (
                <div className="grid gap-2 sm:grid-cols-2">
                  {skills.data?.map((s) => {
                    const active = selectedTools.includes(s.id);
                    return (
                      <button
                        key={s.id}
                        type="button"
                        onClick={() => toggleTool(s.id)}
                        className={cn(
                          "flex items-start gap-3 rounded-md border p-3 text-left transition-all",
                          active ? "border-secondary bg-secondary/10" : "border-border hover:border-border/80"
                        )}
                      >
                        <span className={cn("mt-0.5 flex h-4 w-4 items-center justify-center rounded border", active ? "border-secondary bg-secondary text-secondary-foreground" : "border-border")}>
                          {active && <Check className="h-3 w-3" />}
                        </span>
                        <span>
                          <span className="block text-sm font-medium">{s.name}</span>
                          <span className="block text-xs text-muted-foreground">{s.description}</span>
                        </span>
                      </button>
                    );
                  })}
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Live preview / workflow */}
        <div className="space-y-6">
          <Card className="lg:sticky lg:top-6">
            <CardHeader className="flex-row items-center justify-between space-y-0">
              <CardTitle className="text-base">Preview</CardTitle>
              <StatusBadge status="draft" />
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="glass rounded-md p-4">
                <p className="text-lg font-semibold">{values.name || "Untitled agent"}</p>
                <p className="mono text-xs text-muted-foreground">{slugify(values.name || "untitled")}</p>
                <p className="mt-2 text-sm text-muted-foreground">{values.description || "No description yet."}</p>
              </div>
              <dl className="space-y-2 text-sm">
                <div className="flex justify-between"><dt className="text-muted-foreground">Model</dt><dd className="mono">{values.model}</dd></div>
                <div className="flex justify-between"><dt className="text-muted-foreground">Temperature</dt><dd className="mono">{Number(values.temperature).toFixed(2)}</dd></div>
                <div className="flex justify-between"><dt className="text-muted-foreground">Memory</dt><dd className="mono capitalize">{values.memory?.type}</dd></div>
                <div className="flex justify-between"><dt className="text-muted-foreground">Gateway</dt><dd className="mono">{gateways.data?.find((g) => g.id === values.gatewayId)?.name ?? "default"}</dd></div>
              </dl>
              <div>
                <p className="mono mb-2 text-xs uppercase tracking-wide text-muted-foreground">Tools ({selectedTools.length})</p>
                <div className="flex flex-wrap gap-1.5">
                  {selectedTools.length === 0 && <span className="text-xs text-muted-foreground">None attached</span>}
                  {selectedTools.map((id) => (
                    <Badge key={id} variant="plasma">{skills.data?.find((s) => s.id === id)?.name ?? id}</Badge>
                  ))}
                </div>
              </div>
              <motion.div whileTap={{ scale: 0.98 }}>
                <Button type="submit" className="w-full" disabled={createAgent.isPending}>
                  <Sparkles /> {createAgent.isPending ? "Forging…" : "Forge agent"}
                </Button>
              </motion.div>
              <p className="mono text-center text-[11px] text-muted-foreground">
                Creates the agent, then routes you to deployment.
              </p>
            </CardContent>
          </Card>
        </div>
      </form>
    </div>
  );
}
