"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { Bot, Rocket, Sparkles, Network, Activity, Plus, ArrowRight, CheckCircle2 } from "lucide-react";
import { useStats, useActivity, useDeployments } from "@/lib/hooks/use-hermes";
import { SectionHeading } from "@/components/shared/section-heading";
import { StatCard } from "@/components/shared/stat-card";
import { StatusBadge } from "@/components/shared/status-badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { relativeTime } from "@/lib/utils";

const quickActions = [
  { href: "/agents/new", label: "Forge agent", icon: Bot },
  { href: "/skills/new", label: "New skill", icon: Sparkles },
  { href: "/deployments", label: "Deploy", icon: Rocket },
  { href: "/gateways/new", label: "Add gateway", icon: Network },
];

export default function DashboardPage() {
  const stats = useStats();
  const activity = useActivity();
  const deployments = useDeployments();

  return (
    <div className="space-y-8">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <SectionHeading eyebrow="Console" title="Foundry overview" description="Live state of your agents, skills, and deployments." />
        <Button asChild><Link href="/agents/new"><Plus /> New agent</Link></Button>
      </div>

      {/* Overview cards */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {stats.isLoading
          ? Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-32" />)
          : stats.data && (
              <>
                <StatCard label="Agents" value={stats.data.agents} icon={Bot} trend={`${stats.data.liveDeployments} live`} />
                <StatCard label="Deployments" value={stats.data.deployments} icon={Rocket} accent="plasma" trend="across environments" />
                <StatCard label="Skills" value={stats.data.skills} icon={Sparkles} trend="reusable tools" />
                <StatCard label="Gateways" value={stats.data.gateways} icon={Network} accent="plasma" trend="connected providers" />
              </>
            )}
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        {/* Stats + chart */}
        <Card className="lg:col-span-2">
          <CardHeader className="flex-row items-center justify-between space-y-0">
            <CardTitle className="text-base">Agent calls — last 7 days</CardTitle>
            <Activity className="h-4 w-4 text-secondary" />
          </CardHeader>
          <CardContent>
            {stats.isLoading || !stats.data ? (
              <Skeleton className="h-40" />
            ) : (
              <>
                <div className="flex items-end gap-3">
                  <span className="text-3xl font-semibold">{stats.data.callsToday.toLocaleString()}</span>
                  <span className="mono mb-1 text-xs text-muted-foreground">calls today</span>
                </div>
                <div className="mt-6 flex h-40 items-end gap-2">
                  {stats.data.series.map((d, i) => {
                    const max = Math.max(...stats.data!.series.map((x) => x.value));
                    return (
                      <motion.div
                        key={d.label}
                        initial={{ height: 0 }}
                        animate={{ height: `${(d.value / max) * 100}%` }}
                        transition={{ delay: i * 0.05, duration: 0.5 }}
                        className="group relative flex-1 rounded-t bg-gradient-to-t from-primary/30 to-primary/80"
                      >
                        <span className="mono absolute -top-5 left-1/2 -translate-x-1/2 text-[10px] text-muted-foreground opacity-0 group-hover:opacity-100">
                          {d.value}
                        </span>
                      </motion.div>
                    );
                  })}
                </div>
                <div className="mt-2 flex gap-2">
                  {stats.data.series.map((d) => (
                    <span key={d.label} className="mono flex-1 text-center text-[10px] text-muted-foreground">{d.label}</span>
                  ))}
                </div>
                <div className="mt-6 flex items-center gap-3">
                  <CheckCircle2 className="h-4 w-4 text-emerald-400" />
                  <span className="text-sm text-muted-foreground">Success rate</span>
                  <Progress value={stats.data.successRate * 100} className="flex-1" />
                  <span className="mono text-sm">{(stats.data.successRate * 100).toFixed(1)}%</span>
                </div>
              </>
            )}
          </CardContent>
        </Card>

        {/* Quick actions */}
        <Card>
          <CardHeader><CardTitle className="text-base">Quick actions</CardTitle></CardHeader>
          <CardContent className="grid grid-cols-2 gap-3">
            {quickActions.map((a) => {
              const Icon = a.icon;
              return (
                <Link
                  key={a.href}
                  href={a.href}
                  className="glass group flex flex-col gap-2 rounded-md p-4 transition-all hover:-translate-y-0.5 hover:shadow-glow"
                >
                  <Icon className="h-5 w-5 text-primary transition-transform group-hover:scale-110" />
                  <span className="text-sm font-medium">{a.label}</span>
                </Link>
              );
            })}
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        {/* Recent activity */}
        <Card>
          <CardHeader><CardTitle className="text-base">Recent activity</CardTitle></CardHeader>
          <CardContent className="space-y-3">
            {activity.isLoading
              ? Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-10" />)
              : activity.data?.map((a) => (
                  <div key={a.id} className="flex items-start gap-3 border-b border-border/40 pb-3 last:border-0 last:pb-0">
                    <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-primary" />
                    <div className="flex-1">
                      <p className="text-sm">{a.message}</p>
                      <p className="mono text-xs text-muted-foreground">{relativeTime(a.at)}</p>
                    </div>
                  </div>
                ))}
          </CardContent>
        </Card>

        {/* Deployments */}
        <Card>
          <CardHeader className="flex-row items-center justify-between space-y-0">
            <CardTitle className="text-base">Deployments</CardTitle>
            <Button variant="ghost" size="sm" asChild><Link href="/deployments">All <ArrowRight /></Link></Button>
          </CardHeader>
          <CardContent className="space-y-3">
            {deployments.isLoading
              ? Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-12" />)
              : deployments.data?.slice(0, 4).map((d) => (
                  <div key={d.id} className="flex items-center justify-between gap-3 border-b border-border/40 pb-3 last:border-0 last:pb-0">
                    <div>
                      <p className="text-sm font-medium">{d.agentName}</p>
                      <p className="mono text-xs text-muted-foreground">{d.environment} · {d.version}</p>
                    </div>
                    <StatusBadge status={d.status} />
                  </div>
                ))}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
