"use client";

import { useForm, Controller } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Rocket, History, Server } from "lucide-react";
import { deploymentSchema, type DeploymentForm } from "@/lib/validation/schemas";
import { useAgents, useDeployments, useCreateDeployment } from "@/lib/hooks/use-hermes";
import { SectionHeading } from "@/components/shared/section-heading";
import { StatusBadge } from "@/components/shared/status-badge";
import { EmptyState } from "@/components/shared/empty-state";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { cn, relativeTime } from "@/lib/utils";

const ENVS = [
  { id: "development", label: "Development", hint: "ephemeral · fast iteration" },
  { id: "staging", label: "Staging", hint: "pre-production checks" },
  { id: "production", label: "Production", hint: "live traffic" },
] as const;

export default function DeploymentsPage() {
  const agents = useAgents();
  const deployments = useDeployments();
  const createDeployment = useCreateDeployment();

  const { control, handleSubmit, watch, formState: { errors } } = useForm<DeploymentForm>({
    resolver: zodResolver(deploymentSchema),
    defaultValues: { agentId: "", environment: "staging" },
  });
  const env = watch("environment");

  const onSubmit = (data: DeploymentForm) => createDeployment.mutate(data);

  return (
    <div className="space-y-8">
      <SectionHeading eyebrow="Deployment Center" title="Deploy & operate" description="Promote agents across environments and track deployment status." />

      <div className="grid gap-6 lg:grid-cols-[1fr_1.3fr]">
        {/* Deploy form */}
        <Card className="h-fit">
          <CardHeader className="flex-row items-center gap-2 space-y-0">
            <Rocket className="h-4 w-4 text-primary" /><CardTitle className="text-base">New deployment</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit(onSubmit)} className="space-y-5">
              <div>
                <Label>Agent</Label>
                <Controller
                  control={control}
                  name="agentId"
                  render={({ field }) => (
                    <Select value={field.value} onValueChange={field.onChange}>
                      <SelectTrigger className="mt-1.5"><SelectValue placeholder="Select an agent" /></SelectTrigger>
                      <SelectContent>
                        {agents.data?.map((a) => <SelectItem key={a.id} value={a.id}>{a.name}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  )}
                />
                {errors.agentId && <p className="mono mt-1 text-xs text-destructive">{errors.agentId.message}</p>}
              </div>

              <div>
                <Label>Environment</Label>
                <Controller
                  control={control}
                  name="environment"
                  render={({ field }) => (
                    <div className="mt-1.5 space-y-2">
                      {ENVS.map((e) => (
                        <button
                          key={e.id}
                          type="button"
                          onClick={() => field.onChange(e.id)}
                          className={cn(
                            "flex w-full items-center justify-between rounded-md border p-3 text-left transition-all",
                            field.value === e.id ? "border-primary bg-primary/10" : "border-border hover:border-border/80"
                          )}
                        >
                          <span>
                            <span className="block text-sm font-medium">{e.label}</span>
                            <span className="mono block text-xs text-muted-foreground">{e.hint}</span>
                          </span>
                          <Server className={cn("h-4 w-4", field.value === e.id ? "text-primary" : "text-muted-foreground")} />
                        </button>
                      ))}
                    </div>
                  )}
                />
              </div>

              <Button type="submit" className="w-full" disabled={createDeployment.isPending}>
                <Rocket /> {createDeployment.isPending ? "Shipping…" : `Deploy to ${env}`}
              </Button>
            </form>
          </CardContent>
        </Card>

        {/* History */}
        <Card>
          <CardHeader className="flex-row items-center gap-2 space-y-0">
            <History className="h-4 w-4 text-secondary" /><CardTitle className="text-base">Deployment history</CardTitle>
          </CardHeader>
          <CardContent>
            {deployments.isLoading ? (
              <div className="space-y-3">{Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-16" />)}</div>
            ) : deployments.data && deployments.data.length > 0 ? (
              <div className="space-y-3">
                {deployments.data.map((d) => (
                  <div key={d.id} className="glass flex items-center justify-between gap-3 rounded-md p-4">
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <p className="truncate font-medium">{d.agentName}</p>
                        <span className="mono text-xs text-muted-foreground">{d.version}</span>
                      </div>
                      <p className="mono text-xs text-muted-foreground">
                        {d.environment} · {relativeTime(d.createdAt)}
                        {d.url && <> · <a href={d.url} className="text-secondary hover:underline">{d.url.replace("https://", "")}</a></>}
                      </p>
                    </div>
                    <StatusBadge status={d.status} />
                  </div>
                ))}
              </div>
            ) : (
              <EmptyState icon={Rocket} title="No deployments yet" description="Ship your first agent to see it here." />
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
