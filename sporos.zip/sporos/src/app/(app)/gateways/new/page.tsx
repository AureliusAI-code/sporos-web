"use client";

import { useState } from "react";
import { useForm, Controller } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Network, Plus, X, KeyRound } from "lucide-react";
import { gatewaySchema, type GatewayForm } from "@/lib/validation/schemas";
import { useGateways, useCreateGateway } from "@/lib/hooks/use-hermes";
import { SectionHeading } from "@/components/shared/section-heading";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { cn } from "@/lib/utils";
import type { GatewayProvider } from "@/lib/api/types";

const PROVIDERS: { id: GatewayProvider; label: string; needsUrl?: boolean }[] = [
  { id: "openai", label: "OpenAI" },
  { id: "anthropic", label: "Anthropic" },
  { id: "azure-openai", label: "Azure OpenAI", needsUrl: true },
  { id: "google-vertex", label: "Google Vertex", needsUrl: true },
  { id: "mistral", label: "Mistral" },
  { id: "groq", label: "Groq" },
  { id: "ollama", label: "Ollama", needsUrl: true },
];

export default function GatewayBuilderPage() {
  const gateways = useGateways();
  const createGateway = useCreateGateway();
  const [models, setModels] = useState<string[]>([]);
  const [modelDraft, setModelDraft] = useState("");

  const { register, handleSubmit, control, watch, setValue, formState: { errors }, reset } = useForm<GatewayForm>({
    resolver: zodResolver(gatewaySchema),
    defaultValues: { name: "", provider: "openai", baseUrl: "", apiKey: "", models: [] },
  });
  const provider = watch("provider");
  const needsUrl = PROVIDERS.find((p) => p.id === provider)?.needsUrl;

  const addModel = () => {
    const m = modelDraft.trim();
    if (!m || models.includes(m)) return;
    const next = [...models, m];
    setModels(next); setValue("models", next); setModelDraft("");
  };
  const removeModel = (m: string) => {
    const next = models.filter((x) => x !== m);
    setModels(next); setValue("models", next);
  };

  const onSubmit = async (data: GatewayForm) => {
    await createGateway.mutateAsync({ ...data, baseUrl: data.baseUrl || undefined });
    reset(); setModels([]);
  };

  return (
    <div className="space-y-8">
      <SectionHeading eyebrow="Gateway Builder" title="Connect a provider" description="Route agents through any LLM provider behind a unified gateway." />

      <div className="grid gap-6 lg:grid-cols-[1.2fr_1fr]">
        <Card className="h-fit">
          <CardHeader className="flex-row items-center gap-2 space-y-0">
            <Network className="h-4 w-4 text-primary" /><CardTitle className="text-base">Configuration</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit(onSubmit)} className="space-y-5">
              <div>
                <Label htmlFor="gname">Name</Label>
                <Input id="gname" placeholder="OpenAI Primary" {...register("name")} className="mt-1.5" />
                {errors.name && <p className="mono mt-1 text-xs text-destructive">{errors.name.message}</p>}
              </div>

              <div>
                <Label>Provider</Label>
                <Controller
                  control={control}
                  name="provider"
                  render={({ field }) => (
                    <div className="mt-1.5 grid grid-cols-2 gap-2 sm:grid-cols-3">
                      {PROVIDERS.map((p) => (
                        <button
                          key={p.id}
                          type="button"
                          onClick={() => field.onChange(p.id)}
                          className={cn(
                            "rounded-md border px-3 py-2 text-sm transition-all",
                            field.value === p.id ? "border-primary bg-primary/10 text-foreground" : "border-border text-muted-foreground hover:border-border/80"
                          )}
                        >
                          {p.label}
                        </button>
                      ))}
                    </div>
                  )}
                />
              </div>

              {needsUrl && (
                <div>
                  <Label htmlFor="burl">Base URL</Label>
                  <Input id="burl" placeholder="https://your-endpoint.example.com" {...register("baseUrl")} className="mt-1.5" />
                  {errors.baseUrl && <p className="mono mt-1 text-xs text-destructive">{errors.baseUrl.message}</p>}
                </div>
              )}

              <div>
                <Label htmlFor="key">API key</Label>
                <div className="relative mt-1.5">
                  <KeyRound className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <Input id="key" type="password" placeholder="sk-…" {...register("apiKey")} className="pl-9" />
                </div>
                {errors.apiKey && <p className="mono mt-1 text-xs text-destructive">{errors.apiKey.message}</p>}
              </div>

              <div>
                <Label>Models</Label>
                <div className="mt-1.5 flex gap-2">
                  <Input
                    value={modelDraft}
                    onChange={(e) => setModelDraft(e.target.value)}
                    onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); addModel(); } }}
                    placeholder="gpt-4o"
                  />
                  <Button type="button" variant="outline" onClick={addModel}><Plus /></Button>
                </div>
                <div className="mt-2 flex flex-wrap gap-1.5">
                  {models.map((m) => (
                    <Badge key={m} variant="muted" className="gap-1">
                      {m}
                      <button type="button" onClick={() => removeModel(m)}><X className="h-3 w-3" /></button>
                    </Badge>
                  ))}
                </div>
                {errors.models && <p className="mono mt-1 text-xs text-destructive">{errors.models.message as string}</p>}
              </div>

              <Button type="submit" className="w-full" disabled={createGateway.isPending}>
                <Network /> {createGateway.isPending ? "Connecting…" : "Connect gateway"}
              </Button>
            </form>
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle className="text-base">Connected gateways</CardTitle></CardHeader>
          <CardContent className="space-y-3">
            {gateways.isLoading
              ? Array.from({ length: 2 }).map((_, i) => <Skeleton key={i} className="h-16" />)
              : gateways.data?.map((g) => (
                  <div key={g.id} className="glass flex items-center justify-between gap-3 rounded-md p-4">
                    <div>
                      <div className="flex items-center gap-2">
                        <p className="font-medium">{g.name}</p>
                        <Badge variant={g.active ? "success" : "muted"}>{g.active ? "active" : "off"}</Badge>
                      </div>
                      <p className="mono text-xs text-muted-foreground">{g.provider} · {g.models.length} models</p>
                    </div>
                  </div>
                ))}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
