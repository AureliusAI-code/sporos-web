import { AppSidebar } from "@/components/layout/app-sidebar";
import { ErrorBoundary } from "@/components/shared/error-boundary";

export default function AppLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex min-h-screen">
      <AppSidebar />
      <div className="flex min-w-0 flex-1 flex-col">
        <main className="flex-1 px-4 py-6 sm:px-6 lg:px-10 lg:py-10">
          <ErrorBoundary>
            <div className="mx-auto w-full max-w-6xl">{children}</div>
          </ErrorBoundary>
        </main>
      </div>
    </div>
  );
}
