"use client";

import { useEffect } from "react";
import { useForm } from "react-hook-form";
import { motion } from "framer-motion";
import { Cpu, Search, ExternalLink, ShieldCheck, Wrench } from "lucide-react";
import { useRecommendMcp } from "@/lib/hooks/use-hermes";
import { SectionHeading } from "@/components/shared/section-heading";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Progress } from "@/components/ui/progress";

export default function McpCenterPage() {
  const recommend = useRecommendMcp();
  const { register, handleSubmit } = useForm<{ query: string }>({ defaultValues: { query: "" } });

  // initial recommendations
  useEffect(() => {
    recommend.mutate("");
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const onSubmit = ({ query }: { query: string }) => recommend.mutate(query);

  return (
    <div className="space-y-8">
      <SectionHeading
        eyebrow="MCP Center"
        title="Recommend Model Context Protocol servers"
        description="Describe a capability your agent needs and get ranked, connectable MCP servers."
      />

      <form onSubmit={handleSubmit(onSubmit)} className="flex gap-2">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input {...register("query")} placeholder="e.g. query a Postgres database and post to Slack" className="pl-9" />
        </div>
        <Button type="submit" disabled={recommend.isPending}><Cpu /> Recommend</Button>
      </form>

      <div className="grid gap-4 sm:grid-cols-2">
        {recommend.isPending
          ? Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-40" />)
          : recommend.data?.map((m, i) => (
              <motion.div
                key={m.id}
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05 }}
              >
                <Card className="h-full transition-all hover:-translate-y-0.5 hover:shadow-glow">
                  <CardContent className="space-y-3 p-5">
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <div className="flex h-9 w-9 items-center justify-center rounded-md bg-secondary/10 text-secondary">
                          <Cpu className="h-4 w-4" />
                        </div>
                        <div>
                          <p className="flex items-center gap-1.5 font-medium">
                            {m.name}
                            {m.verified && <ShieldCheck className="h-3.5 w-3.5 text-emerald-400" />}
                          </p>
                          <Badge variant="muted">{m.category}</Badge>
                        </div>
                      </div>
                      <a href={m.url} target="_blank" rel="noreferrer" className="text-muted-foreground hover:text-foreground">
                        <ExternalLink className="h-4 w-4" />
                      </a>
                    </div>
                    <p className="text-sm text-muted-foreground">{m.description}</p>
                    <div className="flex items-center gap-2">
                      <Wrench className="h-3.5 w-3.5 text-muted-foreground" />
                      <span className="mono text-xs text-muted-foreground">{m.tools} tools</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Progress value={Math.max(0, m.score) * 100} className="flex-1" />
                      <span className="mono text-xs text-primary">{Math.round(Math.max(0, m.score) * 100)}%</span>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
      </div>
    </div>
  );
}
