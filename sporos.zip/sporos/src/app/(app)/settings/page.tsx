"use client";

import { useState } from "react";
import { toast } from "sonner";
import { Settings2, Palette, Plug, Building2, Save, Wifi, WifiOff } from "lucide-react";
import { SectionHeading } from "@/components/shared/section-heading";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { cn } from "@/lib/utils";

const ACCENTS = [
  { id: "ember", label: "Ember", className: "bg-primary" },
  { id: "plasma", label: "Plasma", className: "bg-secondary" },
  { id: "emerald", label: "Verdant", className: "bg-emerald-500" },
] as const;

export default function SettingsPage() {
  const apiBase = process.env.NEXT_PUBLIC_API_BASE ?? "/hermes";
  const [accent, setAccent] = useState<string>("ember");
  const [reducedMotion, setReducedMotion] = useState(false);
  const [emailDigest, setEmailDigest] = useState(true);
  const [endpoint, setEndpoint] = useState(apiBase);

  return (
    <div className="space-y-8">
      <SectionHeading eyebrow="Settings" title="Workspace settings" description="Manage preferences, appearance, API configuration, and your workspace." />

      <Tabs defaultValue="preferences">
        <TabsList className="flex-wrap">
          <TabsTrigger value="preferences"><Settings2 className="h-4 w-4" /> Preferences</TabsTrigger>
          <TabsTrigger value="appearance"><Palette className="h-4 w-4" /> Appearance</TabsTrigger>
          <TabsTrigger value="api"><Plug className="h-4 w-4" /> API</TabsTrigger>
          <TabsTrigger value="workspace"><Building2 className="h-4 w-4" /> Workspace</TabsTrigger>
        </TabsList>

        {/* Preferences */}
        <TabsContent value="preferences">
          <Card>
            <CardHeader><CardTitle className="text-base">User preferences</CardTitle></CardHeader>
            <CardContent className="space-y-5">
              <div className="grid gap-4 sm:grid-cols-2">
                <div>
                  <Label htmlFor="dname">Display name</Label>
                  <Input id="dname" defaultValue="Operator" className="mt-1.5" />
                </div>
                <div>
                  <Label htmlFor="email">Email</Label>
                  <Input id="email" type="email" defaultValue="operator@sporos.run" className="mt-1.5" />
                </div>
              </div>
              <Separator />
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium">Email digest</p>
                  <p className="text-xs text-muted-foreground">Weekly summary of deployments and agent activity.</p>
                </div>
                <Switch checked={emailDigest} onCheckedChange={setEmailDigest} />
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium">Default deployment environment</p>
                  <p className="text-xs text-muted-foreground">Pre-selected when shipping an agent.</p>
                </div>
                <Select defaultValue="staging">
                  <SelectTrigger className="w-44"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="development">Development</SelectItem>
                    <SelectItem value="staging">Staging</SelectItem>
                    <SelectItem value="production">Production</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <Button onClick={() => toast.success("Preferences saved")}><Save /> Save preferences</Button>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Appearance */}
        <TabsContent value="appearance">
          <Card>
            <CardHeader><CardTitle className="text-base">Theme controls</CardTitle></CardHeader>
            <CardContent className="space-y-5">
              <div>
                <Label>Accent color</Label>
                <div className="mt-2 flex gap-3">
                  {ACCENTS.map((a) => (
                    <button
                      key={a.id}
                      type="button"
                      onClick={() => { setAccent(a.id); toast.success(`Accent set to ${a.label}`); }}
                      className={cn(
                        "flex items-center gap-2 rounded-md border px-3 py-2 text-sm transition-all",
                        accent === a.id ? "border-primary" : "border-border hover:border-border/80"
                      )}
                    >
                      <span className={cn("h-4 w-4 rounded-full", a.className)} />
                      {a.label}
                    </button>
                  ))}
                </div>
                <p className="mono mt-2 text-[11px] text-muted-foreground">
                  Sporos ships dark-first. Accent maps to the foundry glow.
                </p>
              </div>
              <Separator />
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium">Reduce motion</p>
                  <p className="text-xs text-muted-foreground">Pause the drifting spore field and scanline.</p>
                </div>
                <Switch checked={reducedMotion} onCheckedChange={setReducedMotion} />
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium">Glassmorphism</p>
                  <p className="text-xs text-muted-foreground">Frosted translucency on panels.</p>
                </div>
                <Switch defaultChecked />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* API */}
        <TabsContent value="api">
          <Card>
            <CardHeader><CardTitle className="text-base">API configuration</CardTitle></CardHeader>
            <CardContent className="space-y-5">
              <div>
                <Label htmlFor="endpoint">Hermes endpoint (proxy base)</Label>
                <Input id="endpoint" value={endpoint} onChange={(e) => setEndpoint(e.target.value)} className="mt-1.5" />
                <p className="mono mt-2 text-[11px] text-muted-foreground">
                  Set <span className="text-primary">HERMES_API_URL</span> in your environment to point at the FastAPI backend.
                  Requests are proxied through <span className="text-primary">/hermes</span> to avoid CORS.
                </p>
              </div>
              <Separator />
              <div className="glass flex items-center justify-between rounded-md p-4">
                <div className="flex items-center gap-3">
                  <span className="flex h-9 w-9 items-center justify-center rounded-md bg-muted">
                    {process.env.NEXT_PUBLIC_API_BASE ? <Wifi className="h-4 w-4 text-emerald-400" /> : <WifiOff className="h-4 w-4 text-muted-foreground" />}
                  </span>
                  <div>
                    <p className="text-sm font-medium">Connection mode</p>
                    <p className="mono text-xs text-muted-foreground">
                      Live when Hermes is reachable; deterministic local data otherwise.
                    </p>
                  </div>
                </div>
                <Badge variant="success">auto-fallback</Badge>
              </div>
              <div>
                <Label htmlFor="token">API token</Label>
                <Input id="token" type="password" placeholder="sporos_pat_…" className="mt-1.5" />
              </div>
              <Button onClick={() => toast.success("API configuration saved")}><Save /> Save configuration</Button>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Workspace */}
        <TabsContent value="workspace">
          <Card>
            <CardHeader><CardTitle className="text-base">Workspace settings</CardTitle></CardHeader>
            <CardContent className="space-y-5">
              <div className="grid gap-4 sm:grid-cols-2">
                <div>
                  <Label htmlFor="wname">Workspace name</Label>
                  <Input id="wname" defaultValue="Sporos Labs" className="mt-1.5" />
                </div>
                <div>
                  <Label htmlFor="wslug">Slug</Label>
                  <Input id="wslug" defaultValue="sporos-labs" className="mt-1.5" />
                </div>
              </div>
              <Separator />
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium">Region</p>
                  <p className="text-xs text-muted-foreground">Where deployments are provisioned.</p>
                </div>
                <Select defaultValue="us-east">
                  <SelectTrigger className="w-44"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="us-east">us-east</SelectItem>
                    <SelectItem value="us-west">us-west</SelectItem>
                    <SelectItem value="eu-central">eu-central</SelectItem>
                    <SelectItem value="ap-south">ap-south</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <Separator />
              <div className="glass flex items-center justify-between rounded-md border-destructive/30 p-4">
                <div>
                  <p className="text-sm font-medium text-destructive">Danger zone</p>
                  <p className="text-xs text-muted-foreground">Permanently delete this workspace and all agents.</p>
                </div>
                <Button variant="destructive" onClick={() => toast.error("Deletion requires confirmation")}>Delete</Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
