"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import { LayoutTemplate, Search, Flame, ArrowRight } from "lucide-react";
import { useTemplates } from "@/lib/hooks/use-hermes";
import { SectionHeading } from "@/components/shared/section-heading";
import { EmptyState } from "@/components/shared/empty-state";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { cn } from "@/lib/utils";
import type { Template } from "@/lib/api/types";

export default function TemplatesPage() {
  const templates = useTemplates();
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("all");
  const [selected, setSelected] = useState<Template | null>(null);

  const categories = useMemo(() => {
    const set = new Set<string>();
    templates.data?.forEach((t) => set.add(t.category));
    return ["all", ...Array.from(set)];
  }, [templates.data]);

  const filtered = useMemo(() => {
    return (templates.data ?? [])
      .filter((t) => category === "all" || t.category === category)
      .filter((t) => {
        const q = query.trim().toLowerCase();
        if (!q) return true;
        return (
          t.name.toLowerCase().includes(q) ||
          t.description.toLowerCase().includes(q) ||
          t.tags.some((tag) => tag.toLowerCase().includes(q))
        );
      })
      .sort((a, b) => b.popularity - a.popularity);
  }, [templates.data, category, query]);

  return (
    <div className="space-y-8">
      <SectionHeading
        eyebrow="Templates"
        title="Start from a proven preset"
        description="Browse curated agent templates by category, then forge your own from any of them."
      />

      <div className="flex flex-col gap-3 sm:flex-row">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search templates…" className="pl-9" />
        </div>
        <Select value={category} onValueChange={setCategory}>
          <SelectTrigger className="sm:w-52"><SelectValue /></SelectTrigger>
          <SelectContent>
            {categories.map((c) => (
              <SelectItem key={c} value={c} className="capitalize">{c === "all" ? "All categories" : c}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="grid gap-6 lg:grid-cols-[1.5fr_1fr]">
        {/* Grid */}
        <div className="grid gap-4 sm:grid-cols-2">
          {templates.isLoading ? (
            Array.from({ length: 6 }).map((_, i) => <Skeleton key={i} className="h-44" />)
          ) : filtered.length > 0 ? (
            filtered.map((t, i) => (
              <motion.button
                key={t.id}
                type="button"
                onClick={() => setSelected(t)}
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: (i % 6) * 0.05 }}
                className={cn(
                  "glass group rounded-lg p-5 text-left transition-all hover:-translate-y-1 hover:shadow-glow",
                  selected?.id === t.id && "ring-1 ring-primary"
                )}
              >
                <div className="flex items-start justify-between">
                  <div className="flex h-10 w-10 items-center justify-center rounded-md bg-primary/10 text-primary">
                    <LayoutTemplate className="h-5 w-5" />
                  </div>
                  <span className="mono flex items-center gap-1 text-xs text-muted-foreground">
                    <Flame className="h-3.5 w-3.5 text-primary" />{t.popularity}
                  </span>
                </div>
                <h3 className="mt-4 font-semibold">{t.name}</h3>
                <p className="mt-1 line-clamp-2 text-sm text-muted-foreground">{t.description}</p>
                <div className="mt-3 flex flex-wrap gap-1.5">
                  <Badge variant="muted">{t.category}</Badge>
                  {t.tags.slice(0, 2).map((tag) => <Badge key={tag} variant="plasma">{tag}</Badge>)}
                </div>
              </motion.button>
            ))
          ) : (
            <div className="sm:col-span-2">
              <EmptyState icon={Search} title="No templates match" description="Try a different search or category." />
            </div>
          )}
        </div>

        {/* Detail / preview */}
        <Card className="h-fit lg:sticky lg:top-6">
          <CardContent className="p-6">
            {selected ? (
              <div className="space-y-5">
                <div>
                  <div className="flex items-center justify-between">
                    <Badge variant="muted">{selected.category}</Badge>
                    <span className="mono flex items-center gap-1 text-xs text-muted-foreground">
                      <Flame className="h-3.5 w-3.5 text-primary" />{selected.popularity}% adoption
                    </span>
                  </div>
                  <h2 className="mt-3 text-xl font-semibold">{selected.name}</h2>
                  <p className="mt-1 text-sm text-muted-foreground">{selected.description}</p>
                </div>

                <div>
                  <p className="mono mb-2 text-xs uppercase tracking-wide text-muted-foreground">Tags</p>
                  <div className="flex flex-wrap gap-1.5">
                    {selected.tags.map((tag) => <Badge key={tag} variant="plasma">{tag}</Badge>)}
                  </div>
                </div>

                <div>
                  <p className="mono mb-2 text-xs uppercase tracking-wide text-muted-foreground">Preset</p>
                  <div className="glass space-y-2 rounded-md p-4 text-sm">
                    <div className="flex justify-between"><span className="text-muted-foreground">Model</span><span className="mono">{selected.agentPreset.model ?? "—"}</span></div>
                    <div className="flex justify-between"><span className="text-muted-foreground">Temperature</span><span className="mono">{selected.agentPreset.temperature ?? "—"}</span></div>
                    <div className="flex justify-between"><span className="text-muted-foreground">Name</span><span className="mono">{selected.agentPreset.name ?? "—"}</span></div>
                  </div>
                </div>

                <Button asChild className="w-full">
                  <Link href="/agents/new"><span>Forge from template</span> <ArrowRight /></Link>
                </Button>
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center gap-3 py-12 text-center">
                <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-muted text-muted-foreground">
                  <LayoutTemplate className="h-5 w-5" />
                </div>
                <p className="text-sm text-muted-foreground">Select a template to see details and preview its preset.</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
