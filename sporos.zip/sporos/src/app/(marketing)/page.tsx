import { Hero } from "@/components/landing/hero";
import { Features } from "@/components/landing/features";
import { FoundryViz } from "@/components/landing/foundry-viz";
import { CTA } from "@/components/landing/cta";

export default function LandingPage() {
  return (
    <>
      <Hero />
      <Features />
      <FoundryViz />
      <CTA />
    </>
  );
}
