import type { Metadata } from "next";
import localFont from "next/font/local";
import "./globals.css";
import { Providers } from "@/components/shared/providers";
import { SporeField } from "@/components/shared/spore-field";

const display = localFont({
  variable: "--font-display",
  display: "swap",
  src: [
    { path: "./fonts/SpaceGrotesk-400.woff2", weight: "400", style: "normal" },
    { path: "./fonts/SpaceGrotesk-500.woff2", weight: "500", style: "normal" },
    { path: "./fonts/SpaceGrotesk-600.woff2", weight: "600", style: "normal" },
    { path: "./fonts/SpaceGrotesk-700.woff2", weight: "700", style: "normal" },
  ],
});

const mono = localFont({
  variable: "--font-mono",
  display: "swap",
  src: [
    { path: "./fonts/JetBrainsMono-400.woff2", weight: "400", style: "normal" },
    { path: "./fonts/JetBrainsMono-500.woff2", weight: "500", style: "normal" },
    { path: "./fonts/JetBrainsMono-600.woff2", weight: "600", style: "normal" },
    { path: "./fonts/JetBrainsMono-700.woff2", weight: "700", style: "normal" },
  ],
});

export const metadata: Metadata = {
  title: "Sporos — AI Foundry",
  description:
    "Sporos is an AI Foundry. Create, manage, deploy, and operate AI agents from natural language.",
  metadataBase: new URL("https://sporos.local"),
  openGraph: {
    title: "Sporos — AI Foundry",
    description: "Forge autonomous agents from natural language.",
    type: "website",
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={`${display.variable} ${mono.variable} dark`}>
      <body className="min-h-screen antialiased">
        <SporeField />
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}
