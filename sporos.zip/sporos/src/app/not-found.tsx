import Link from "next/link";
import { Logo } from "@/components/layout/logo";
import { Button } from "@/components/ui/button";

export default function NotFound() {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center gap-6 px-6 text-center">
      <Logo />
      <div>
        <p className="mono text-6xl font-semibold text-primary">404</p>
        <p className="mt-2 text-muted-foreground">This spore drifted off the grid.</p>
      </div>
      <div className="flex gap-3">
        <Button asChild><Link href="/">Home</Link></Button>
        <Button variant="outline" asChild><Link href="/dashboard">Console</Link></Button>
      </div>
    </div>
  );
}
