"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";

export function CTA() {
  return (
    <section id="cta" className="relative border-t border-border/60 py-24">
      <div className="container">
        <motion.div
          initial={{ opacity: 0, scale: 0.97 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="glass-strong relative overflow-hidden rounded-2xl px-8 py-16 text-center shadow-glow"
        >
          <div className="absolute inset-0 -z-10 bg-gradient-to-br from-primary/10 via-transparent to-secondary/10" />
          <p className="mono text-xs uppercase tracking-[0.2em] text-primary">Start forging</p>
          <h2 className="mx-auto mt-4 max-w-2xl text-3xl font-semibold tracking-tight sm:text-4xl">
            Your next agent is one sentence away.
          </h2>
          <p className="mx-auto mt-4 max-w-xl text-muted-foreground">
            Open the console, describe what you need, and let the foundry handle the wiring.
          </p>
          <div className="mt-8 flex flex-wrap justify-center gap-3">
            <Button size="lg" asChild>
              <Link href="/dashboard">Enter the Foundry <ArrowRight /></Link>
            </Button>
            <Button size="lg" variant="outline" asChild>
              <Link href="/agents/new">Forge an agent</Link>
            </Button>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
