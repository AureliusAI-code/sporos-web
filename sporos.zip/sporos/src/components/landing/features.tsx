"use client";

import { motion } from "framer-motion";
import { Bot, Sparkles, Rocket, Network, Cpu, LayoutTemplate, Brain, ShieldCheck } from "lucide-react";
import { SectionHeading } from "@/components/shared/section-heading";

const features = [
  { icon: Bot, title: "Agent Builder", body: "Describe behaviour in natural language; Sporos configures model, tools, and memory." },
  { icon: Sparkles, title: "Skill Builder", body: "Turn a sentence into a typed, parameterised skill with generated implementation." },
  { icon: Rocket, title: "Deployment Center", body: "Promote across development, staging, and production with live status." },
  { icon: Network, title: "Gateway Builder", body: "Connect any provider — OpenAI, Anthropic, Vertex, Groq, Ollama — behind one interface." },
  { icon: Cpu, title: "MCP Recommendations", body: "Describe a need; get ranked Model Context Protocol servers to plug in." },
  { icon: LayoutTemplate, title: "Templates", body: "Start from battle-tested agent presets and customise from there." },
  { icon: Brain, title: "Memory Engine", body: "Ephemeral, buffered, or vector memory — wired automatically." },
  { icon: ShieldCheck, title: "Operations", body: "Observe calls, success rates, and deployment health from one console." },
];

export function Features() {
  return (
    <section id="features" className="relative border-t border-border/60 py-20">
      <div className="container">
        <SectionHeading
          eyebrow="The Foundry"
          title="Everything to build, ship, and operate agents"
          description="A single surface for the full lifecycle — from a one-line idea to a monitored production deployment."
        />
        <div className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {features.map((f, i) => {
            const Icon = f.icon;
            return (
              <motion.div
                key={f.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-60px" }}
                transition={{ duration: 0.4, delay: (i % 4) * 0.06 }}
                className="glass group rounded-lg p-5 transition-all hover:-translate-y-1 hover:shadow-glow"
              >
                <div className="flex h-10 w-10 items-center justify-center rounded-md bg-primary/10 text-primary transition-transform group-hover:scale-110">
                  <Icon className="h-5 w-5" />
                </div>
                <h3 className="mt-4 font-semibold">{f.title}</h3>
                <p className="mt-1.5 text-sm text-muted-foreground">{f.body}</p>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
