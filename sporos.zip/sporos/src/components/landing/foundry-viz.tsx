"use client";

import { motion } from "framer-motion";
import { MessageSquareText, Cog, Boxes, Rocket } from "lucide-react";
import { SectionHeading } from "@/components/shared/section-heading";

const stages = [
  { icon: MessageSquareText, label: "Describe", sub: "natural language intent" },
  { icon: Cog, label: "Configure", sub: "model · tools · memory" },
  { icon: Boxes, label: "Assemble", sub: "skills + gateways" },
  { icon: Rocket, label: "Deploy", sub: "live & observable" },
];

export function FoundryViz() {
  return (
    <section id="foundry" className="relative border-t border-border/60 py-20">
      <div className="container">
        <SectionHeading
          eyebrow="How it works"
          title="From a sentence to a running agent"
          description="Sporos compiles intent into a fully-wired agent through a transparent pipeline."
          className="text-center [&>*]:mx-auto"
        />

        <div className="relative mt-14">
          {/* connecting beam */}
          <div className="absolute left-0 right-0 top-1/2 hidden h-px -translate-y-1/2 bg-gradient-to-r from-transparent via-primary/40 to-transparent lg:block">
            <motion.span
              className="absolute top-1/2 h-2 w-2 -translate-y-1/2 rounded-full bg-secondary shadow-plasma"
              animate={{ left: ["0%", "100%"] }}
              transition={{ repeat: Infinity, duration: 4, ease: "easeInOut" }}
            />
          </div>

          <div className="grid gap-6 lg:grid-cols-4">
            {stages.map((s, i) => {
              const Icon = s.icon;
              return (
                <motion.div
                  key={s.label}
                  initial={{ opacity: 0, y: 24 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.45, delay: i * 0.12 }}
                  className="glass-strong relative z-10 rounded-xl p-6 text-center"
                >
                  <div className="mono mb-3 text-xs text-muted-foreground">0{i + 1}</div>
                  <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-xl bg-gradient-to-br from-primary/20 to-secondary/20 text-primary">
                    <Icon className="h-6 w-6" />
                  </div>
                  <h3 className="mt-4 font-semibold">{s.label}</h3>
                  <p className="mono mt-1 text-xs text-muted-foreground">{s.sub}</p>
                </motion.div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
