"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { ArrowRight, Terminal } from "lucide-react";
import { Button } from "@/components/ui/button";

const lines = [
  { p: "$", t: "sporos forge agent --from \"a research analyst that cites sources\"" },
  { p: "✓", t: "parsing intent · selecting gpt-4o · attaching web_search" },
  { p: "✓", t: "memory: vector(pgvector) · gateway: openai-primary" },
  { p: "→", t: "agent “Research Analyst” ready · deploy with `sporos ship`" },
];

export function Hero() {
  return (
    <section className="relative overflow-hidden">
      <div className="container grid items-center gap-12 py-20 lg:grid-cols-2 lg:py-28">
        <div>
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="mono inline-flex items-center gap-2 rounded-full border border-border bg-muted/40 px-3 py-1 text-xs text-muted-foreground"
          >
            <span className="h-1.5 w-1.5 animate-pulseGlow rounded-full bg-secondary" />
            AI Foundry · natural language → running agents
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.05 }}
            className="mt-6 text-4xl font-semibold leading-[1.05] tracking-tight sm:text-5xl lg:text-6xl"
          >
            Forge agents from{" "}
            <span className="text-glow text-primary">plain language.</span>{" "}
            Ship them in minutes.
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="mt-5 max-w-xl text-lg text-muted-foreground"
          >
            Sporos is the foundry where you describe what an agent should do — and watch it get
            wired with tools, memory, gateways, and deployments. No glue code.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.15 }}
            className="mt-8 flex flex-wrap gap-3"
          >
            <Button size="lg" asChild>
              <Link href="/dashboard">Enter the Foundry <ArrowRight /></Link>
            </Button>
            <Button size="lg" variant="outline" asChild>
              <Link href="/templates"><Terminal /> Browse templates</Link>
            </Button>
          </motion.div>
        </div>

        {/* Terminal panel */}
        <motion.div
          initial={{ opacity: 0, scale: 0.96 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.7, delay: 0.2 }}
          className="glass-strong relative rounded-xl p-1 shadow-glow"
        >
          <div className="flex items-center gap-2 border-b border-border/60 px-4 py-2.5">
            <span className="h-3 w-3 rounded-full bg-destructive/70" />
            <span className="h-3 w-3 rounded-full bg-amber-400/70" />
            <span className="h-3 w-3 rounded-full bg-emerald-400/70" />
            <span className="mono ml-2 text-xs text-muted-foreground">sporos@foundry — forge</span>
          </div>
          <div className="space-y-2 p-5 font-mono text-sm">
            {lines.map((l, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, x: -8 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.5 + i * 0.5 }}
                className="flex gap-3"
              >
                <span className={l.p === "$" ? "text-primary" : l.p === "→" ? "text-secondary" : "text-emerald-400"}>
                  {l.p}
                </span>
                <span className={l.p === "$" ? "text-foreground" : "text-muted-foreground"}>{l.t}</span>
              </motion.div>
            ))}
            <motion.span
              animate={{ opacity: [1, 0, 1] }}
              transition={{ repeat: Infinity, duration: 1 }}
              className="inline-block h-4 w-2 bg-primary align-middle"
            />
          </div>
        </motion.div>
      </div>
    </section>
  );
}
