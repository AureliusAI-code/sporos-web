"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState } from "react";
import {
  LayoutDashboard, Bot, Sparkles, Rocket, Network, Cpu, LayoutTemplate, Settings,
  Menu, X, ArrowUpRight,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Logo } from "./logo";
import { Button } from "@/components/ui/button";

const nav = [
  { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { href: "/agents/new", label: "Agent Builder", icon: Bot },
  { href: "/skills/new", label: "Skill Builder", icon: Sparkles },
  { href: "/deployments", label: "Deployments", icon: Rocket },
  { href: "/gateways/new", label: "Gateways", icon: Network },
  { href: "/mcp", label: "MCP Center", icon: Cpu },
  { href: "/templates", label: "Templates", icon: LayoutTemplate },
  { href: "/settings", label: "Settings", icon: Settings },
];

function NavList({ onNavigate }: { onNavigate?: () => void }) {
  const pathname = usePathname();
  return (
    <nav className="flex flex-1 flex-col gap-1 p-3">
      {nav.map((item) => {
        const active = pathname === item.href || pathname.startsWith(item.href.replace("/new", ""));
        const Icon = item.icon;
        return (
          <Link
            key={item.href}
            href={item.href}
            onClick={onNavigate}
            className={cn(
              "group flex items-center gap-3 rounded-md px-3 py-2 text-sm transition-all",
              active
                ? "bg-primary/10 text-foreground shadow-[inset_2px_0_0_hsl(var(--primary))]"
                : "text-muted-foreground hover:bg-accent hover:text-foreground"
            )}
          >
            <Icon className={cn("h-4 w-4", active && "text-primary")} />
            {item.label}
          </Link>
        );
      })}
    </nav>
  );
}

export function AppSidebar() {
  const [open, setOpen] = useState(false);
  return (
    <>
      {/* Mobile bar */}
      <div className="sticky top-0 z-40 flex h-14 items-center justify-between border-b border-border/60 px-4 backdrop-blur-xl lg:hidden">
        <Link href="/dashboard"><Logo /></Link>
        <button onClick={() => setOpen(true)} aria-label="Open menu"><Menu /></button>
      </div>

      {/* Mobile drawer */}
      {open && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="absolute inset-0 bg-background/70 backdrop-blur-sm" onClick={() => setOpen(false)} />
          <aside className="absolute left-0 top-0 flex h-full w-72 flex-col glass-strong">
            <div className="flex h-14 items-center justify-between border-b border-border/60 px-4">
              <Logo />
              <button onClick={() => setOpen(false)} aria-label="Close menu"><X /></button>
            </div>
            <NavList onNavigate={() => setOpen(false)} />
          </aside>
        </div>
      )}

      {/* Desktop sidebar */}
      <aside className="sticky top-0 hidden h-screen w-64 shrink-0 flex-col border-r border-border/60 backdrop-blur-xl lg:flex">
        <div className="flex h-16 items-center border-b border-border/60 px-5">
          <Link href="/dashboard"><Logo /></Link>
        </div>
        <NavList />
        <div className="border-t border-border/60 p-3">
          <Button variant="outline" size="sm" className="w-full justify-between" asChild>
            <Link href="/">Landing <ArrowUpRight className="h-3.5 w-3.5" /></Link>
          </Button>
        </div>
      </aside>
    </>
  );
}
