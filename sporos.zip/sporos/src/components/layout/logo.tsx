import { cn } from "@/lib/utils";

export function Logo({ className, showWord = true }: { className?: string; showWord?: boolean }) {
  return (
    <div className={cn("flex items-center gap-2.5", className)}>
      <span className="relative flex h-7 w-7 items-center justify-center">
        <svg viewBox="0 0 32 32" className="h-7 w-7" aria-hidden>
          <defs>
            <radialGradient id="spore" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="hsl(22 95% 60%)" />
              <stop offset="100%" stopColor="hsl(188 90% 48%)" />
            </radialGradient>
          </defs>
          <circle cx="16" cy="16" r="5" fill="url(#spore)" />
          {[0, 60, 120, 180, 240, 300].map((deg) => {
            const r = (deg * Math.PI) / 180;
            const x = 16 + Math.cos(r) * 11;
            const y = 16 + Math.sin(r) * 11;
            return <circle key={deg} cx={x} cy={y} r="2" fill="url(#spore)" opacity="0.8" />;
          })}
        </svg>
        <span className="absolute inset-0 -z-10 rounded-full bg-primary/40 blur-md" />
      </span>
      {showWord && (
        <span className="text-lg font-semibold tracking-tight">
          spor<span className="text-primary">os</span>
        </span>
      )}
    </div>
  );
}
