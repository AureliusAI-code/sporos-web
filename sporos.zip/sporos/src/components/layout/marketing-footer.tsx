import Link from "next/link";
import { Logo } from "./logo";

const cols = [
  { title: "Foundry", items: [["Dashboard", "/dashboard"], ["Agent Builder", "/agents/new"], ["Skill Builder", "/skills/new"], ["Templates", "/templates"]] },
  { title: "Operate", items: [["Deployments", "/deployments"], ["Gateways", "/gateways/new"], ["MCP Center", "/mcp"], ["Settings", "/settings"]] },
  { title: "Resources", items: [["Docs", "#"], ["API", "#"], ["Status", "#"], ["Changelog", "#"]] },
];

export function MarketingFooter() {
  return (
    <footer className="border-t border-border/60">
      <div className="container grid gap-10 py-14 md:grid-cols-[1.5fr_1fr_1fr_1fr]">
        <div className="space-y-4">
          <Logo />
          <p className="max-w-xs text-sm text-muted-foreground">
            An AI Foundry for forging, deploying, and operating autonomous agents from natural language.
          </p>
          <p className="mono text-xs text-muted-foreground">© {new Date().getFullYear()} Sporos Labs</p>
        </div>
        {cols.map((col) => (
          <div key={col.title} className="space-y-3">
            <p className="mono text-xs uppercase tracking-[0.2em] text-primary">{col.title}</p>
            <ul className="space-y-2">
              {col.items.map(([label, href]) => (
                <li key={label}>
                  <Link href={href} className="text-sm text-muted-foreground transition-colors hover:text-foreground">
                    {label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
    </footer>
  );
}
