"use client";

import Link from "next/link";
import { useState } from "react";
import { Menu, X, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Logo } from "./logo";

const links = [
  { href: "#features", label: "Features" },
  { href: "#foundry", label: "Foundry" },
  { href: "#cta", label: "Get started" },
];

export function MarketingNav() {
  const [open, setOpen] = useState(false);
  return (
    <header className="sticky top-0 z-40 border-b border-border/60 backdrop-blur-xl">
      <div className="container flex h-16 items-center justify-between">
        <Link href="/">
          <Logo />
        </Link>
        <nav className="hidden items-center gap-8 md:flex">
          {links.map((l) => (
            <a key={l.href} href={l.href} className="mono text-sm text-muted-foreground transition-colors hover:text-foreground">
              {l.label}
            </a>
          ))}
        </nav>
        <div className="hidden items-center gap-3 md:flex">
          <Button variant="ghost" size="sm" asChild>
            <Link href="/dashboard">Console</Link>
          </Button>
          <Button size="sm" asChild>
            <Link href="/dashboard">Enter Foundry <ArrowRight /></Link>
          </Button>
        </div>
        <button className="md:hidden" onClick={() => setOpen((o) => !o)} aria-label="Menu">
          {open ? <X /> : <Menu />}
        </button>
      </div>
      {open && (
        <div className="border-t border-border/60 md:hidden">
          <div className="container flex flex-col gap-3 py-4">
            {links.map((l) => (
              <a key={l.href} href={l.href} className="mono text-sm text-muted-foreground" onClick={() => setOpen(false)}>
                {l.label}
              </a>
            ))}
            <Button asChild className="mt-2">
              <Link href="/dashboard">Enter Foundry <ArrowRight /></Link>
            </Button>
          </div>
        </div>
      )}
    </header>
  );
}
