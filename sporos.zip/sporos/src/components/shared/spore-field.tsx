"use client";

import { useEffect, useRef } from "react";

/**
 * SporeField — a canvas of drifting luminous spores (the Sporos motif).
 * Lightweight, respects prefers-reduced-motion, and sits behind all content.
 */
export function SporeField() {
  const ref = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    let raf = 0;
    let w = 0;
    let h = 0;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);

    type Spore = { x: number; y: number; vx: number; vy: number; r: number; hue: number; a: number };
    let spores: Spore[] = [];

    const resize = () => {
      w = canvas.clientWidth;
      h = canvas.clientHeight;
      canvas.width = w * dpr;
      canvas.height = h * dpr;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      const count = Math.min(70, Math.floor((w * h) / 22000));
      spores = Array.from({ length: count }, () => ({
        x: Math.random() * w,
        y: Math.random() * h,
        vx: (Math.random() - 0.5) * 0.18,
        vy: (Math.random() - 0.5) * 0.18,
        r: Math.random() * 1.8 + 0.4,
        hue: Math.random() > 0.5 ? 22 : 188, // ember or plasma
        a: Math.random() * 0.5 + 0.2,
      }));
    };

    const draw = () => {
      ctx.clearRect(0, 0, w, h);
      for (let i = 0; i < spores.length; i++) {
        const s = spores[i];
        s.x += s.vx;
        s.y += s.vy;
        if (s.x < 0) s.x = w;
        if (s.x > w) s.x = 0;
        if (s.y < 0) s.y = h;
        if (s.y > h) s.y = 0;

        // connective filaments
        for (let j = i + 1; j < spores.length; j++) {
          const o = spores[j];
          const dx = s.x - o.x;
          const dy = s.y - o.y;
          const d = Math.hypot(dx, dy);
          if (d < 120) {
            ctx.strokeStyle = `hsla(${s.hue}, 90%, 55%, ${(1 - d / 120) * 0.08})`;
            ctx.lineWidth = 0.5;
            ctx.beginPath();
            ctx.moveTo(s.x, s.y);
            ctx.lineTo(o.x, o.y);
            ctx.stroke();
          }
        }
        ctx.beginPath();
        ctx.fillStyle = `hsla(${s.hue}, 95%, 60%, ${s.a})`;
        ctx.shadowBlur = 8;
        ctx.shadowColor = `hsla(${s.hue}, 95%, 60%, ${s.a})`;
        ctx.arc(s.x, s.y, s.r, 0, Math.PI * 2);
        ctx.fill();
        ctx.shadowBlur = 0;
      }
      raf = requestAnimationFrame(draw);
    };

    resize();
    window.addEventListener("resize", resize);
    if (!reduced) draw();
    else {
      // single static frame
      draw();
      cancelAnimationFrame(raf);
    }

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", resize);
    };
  }, []);

  return (
    <div aria-hidden className="pointer-events-none fixed inset-0 -z-10 overflow-hidden">
      <canvas ref={ref} className="h-full w-full opacity-70" />
      <div className="absolute inset-0 animate-scanline bg-gradient-to-b from-transparent via-primary/[0.02] to-transparent" />
    </div>
  );
}
