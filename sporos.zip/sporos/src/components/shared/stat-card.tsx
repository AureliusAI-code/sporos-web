import { cn } from "@/lib/utils";
import type { LucideIcon } from "lucide-react";

export function StatCard({
  label,
  value,
  icon: Icon,
  trend,
  accent = "ember",
}: {
  label: string;
  value: string | number;
  icon: LucideIcon;
  trend?: string;
  accent?: "ember" | "plasma";
}) {
  return (
    <div className="glass group relative overflow-hidden rounded-lg p-5 transition-all hover:-translate-y-0.5">
      <div
        className={cn(
          "absolute -right-8 -top-8 h-24 w-24 rounded-full opacity-20 blur-2xl transition-opacity group-hover:opacity-40",
          accent === "ember" ? "bg-primary" : "bg-secondary"
        )}
      />
      <div className="flex items-start justify-between">
        <p className="mono text-xs uppercase tracking-wide text-muted-foreground">{label}</p>
        <Icon className={cn("h-4 w-4", accent === "ember" ? "text-primary" : "text-secondary")} />
      </div>
      <p className="mt-3 text-3xl font-semibold tracking-tight">{value}</p>
      {trend && <p className="mono mt-1 text-xs text-muted-foreground">{trend}</p>}
    </div>
  );
}
