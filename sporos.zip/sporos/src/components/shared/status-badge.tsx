import { Badge } from "@/components/ui/badge";
import type { AgentStatus, DeploymentStatus } from "@/lib/api/types";

const map: Record<string, { variant: "default" | "plasma" | "muted" | "success" | "warning" | "danger"; label: string }> = {
  draft: { variant: "muted", label: "draft" },
  ready: { variant: "plasma", label: "ready" },
  deployed: { variant: "success", label: "deployed" },
  error: { variant: "danger", label: "error" },
  queued: { variant: "muted", label: "queued" },
  building: { variant: "warning", label: "building" },
  live: { variant: "success", label: "live" },
  failed: { variant: "danger", label: "failed" },
  stopped: { variant: "muted", label: "stopped" },
};

export function StatusBadge({ status }: { status: AgentStatus | DeploymentStatus }) {
  const cfg = map[status] ?? { variant: "muted" as const, label: status };
  return (
    <Badge variant={cfg.variant} className="gap-1.5">
      <span className="relative flex h-1.5 w-1.5">
        {(status === "live" || status === "building") && (
          <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-current opacity-60" />
        )}
        <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-current" />
      </span>
      {cfg.label}
    </Badge>
  );
}
