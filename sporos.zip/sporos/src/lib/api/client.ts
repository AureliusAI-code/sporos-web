import { ROUTES } from "./routes";
import * as mock from "./mock";
import type {
  Agent, CreateAgentInput, Skill, CreateSkillInput, Deployment, CreateDeploymentInput,
  Gateway, CreateGatewayInput, McpRecommendation, Template, DashboardStats, ActivityItem,
} from "./types";

const BASE = process.env.NEXT_PUBLIC_API_BASE ?? "/hermes";

export class HermesError extends Error {
  status: number;
  constructor(message: string, status: number) {
    super(message);
    this.status = status;
    this.name = "HermesError";
  }
}

type Opts = { method?: string; body?: unknown; signal?: AbortSignal };

/**
 * Core request. Attempts the live Hermes endpoint; on a network failure
 * (backend not running) it throws a sentinel so callers can fall back to
 * deterministic local data. HTTP errors from a *reachable* backend surface
 * as HermesError so toasts/error boundaries can show real messages.
 */
async function request<T>(path: string, opts: Opts = {}): Promise<T> {
  const res = await fetch(`${BASE}${path}`, {
    method: opts.method ?? "GET",
    headers: { "Content-Type": "application/json" },
    body: opts.body ? JSON.stringify(opts.body) : undefined,
    signal: opts.signal,
    cache: "no-store",
  });
  if (!res.ok) {
    let detail = res.statusText;
    try {
      const data = await res.json();
      detail = data?.detail ?? detail;
    } catch {
      /* ignore */
    }
    throw new HermesError(detail, res.status);
  }
  if (res.status === 204) return undefined as T;
  return (await res.json()) as T;
}

const UNREACHABLE = "__hermes_unreachable__";

async function live<T>(path: string, opts: Opts, fallback: () => T | Promise<T>): Promise<T> {
  try {
    return await request<T>(path, opts);
  } catch (err) {
    // Distinguish "backend down" (TypeError from fetch) from real HTTP errors.
    if (err instanceof HermesError) throw err;
    if (process.env.NODE_ENV !== "production") {
      // eslint-disable-next-line no-console
      console.warn(`[hermes] ${path} unreachable — using local data (${UNREACHABLE})`);
    }
    return await fallback();
  }
}

export const api = {
  // Dashboard
  getStats: () => live<DashboardStats>(ROUTES.stats, {}, mock.stats),
  getActivity: () => live<ActivityItem[]>(ROUTES.activity, {}, mock.activity),

  // Agents
  listAgents: () => live<Agent[]>(ROUTES.agents, {}, mock.agents),
  getAgent: (id: string) => live<Agent>(ROUTES.agent(id), {}, () => mock.agent(id)),
  createAgent: (input: CreateAgentInput) =>
    live<Agent>(ROUTES.agents, { method: "POST", body: input }, () => mock.createAgent(input)),
  deleteAgent: (id: string) =>
    live<void>(ROUTES.agent(id), { method: "DELETE" }, () => undefined),

  // Skills
  listSkills: () => live<Skill[]>(ROUTES.skills, {}, mock.skills),
  createSkill: (input: CreateSkillInput) =>
    live<Skill>(ROUTES.skills, { method: "POST", body: input }, () => mock.createSkill(input)),
  generateSkill: (input: CreateSkillInput) =>
    live<Skill>(ROUTES.generateSkill, { method: "POST", body: input }, () => mock.createSkill(input)),

  // Deployments
  listDeployments: () => live<Deployment[]>(ROUTES.deployments, {}, mock.deployments),
  createDeployment: (input: CreateDeploymentInput) =>
    live<Deployment>(ROUTES.deployments, { method: "POST", body: input }, () => mock.createDeployment(input)),

  // Gateways
  listGateways: () => live<Gateway[]>(ROUTES.gateways, {}, mock.gateways),
  createGateway: (input: CreateGatewayInput) =>
    live<Gateway>(ROUTES.gateways, { method: "POST", body: input }, () => mock.createGateway(input)),

  // MCP
  recommendMcp: (query: string) =>
    live<McpRecommendation[]>(ROUTES.mcpRecommend, { method: "POST", body: { query } }, () => mock.mcp(query)),

  // Templates
  listTemplates: () => live<Template[]>(ROUTES.templates, {}, mock.templates),
  getTemplate: (id: string) => live<Template>(ROUTES.template(id), {}, () => mock.template(id)),
};

export type Api = typeof api;
