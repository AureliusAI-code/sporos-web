/**
 * Deterministic local data. Used only when the live Hermes backend is
 * unreachable, so the UI is fully explorable immediately after install.
 * Once HERMES_API_URL points at a running backend, the client uses live data
 * and this module is never touched.
 */
import { slugify } from "../utils";
import type {
  Agent, CreateAgentInput, Skill, CreateSkillInput, Deployment, CreateDeploymentInput,
  Gateway, CreateGatewayInput, McpRecommendation, Template, DashboardStats, ActivityItem,
} from "./types";

const now = () => new Date().toISOString();
const ago = (m: number) => new Date(Date.now() - m * 60000).toISOString();
const rid = () => Math.random().toString(36).slice(2, 10);

let AGENTS: Agent[] = [
  {
    id: "agt_orchestrator", name: "Orchestrator", slug: "orchestrator",
    description: "Routes incoming tasks to specialised sub-agents.",
    instructions: "You are a routing coordinator. Decompose requests and dispatch to the best tool.",
    model: "gpt-4o", temperature: 0.3, status: "deployed",
    tools: ["skill_web_search", "skill_summarise"],
    memory: { type: "vector", window: 20, vectorStore: "pgvector", embedModel: "text-embedding-3-small" },
    gatewayId: "gw_openai", createdAt: ago(4320), updatedAt: ago(120),
  },
  {
    id: "agt_scribe", name: "Scribe", slug: "scribe",
    description: "Drafts and refines long-form documents.",
    instructions: "You are a meticulous writing assistant focused on clarity and structure.",
    model: "claude-3-5-sonnet", temperature: 0.6, status: "ready",
    tools: ["skill_summarise"],
    memory: { type: "buffer", window: 12 },
    gatewayId: "gw_anthropic", createdAt: ago(2880), updatedAt: ago(300),
  },
  {
    id: "agt_sentinel", name: "Sentinel", slug: "sentinel",
    description: "Monitors logs and flags anomalies in real time.",
    instructions: "You watch streaming telemetry and raise alerts on anomalous patterns.",
    model: "gpt-4o-mini", temperature: 0.1, status: "draft",
    tools: [], memory: { type: "ephemeral", window: 0 },
    createdAt: ago(120), updatedAt: ago(20),
  },
];

let SKILLS: Skill[] = [
  {
    id: "skill_web_search", name: "Web Search", slug: "web-search",
    description: "Query the open web and return ranked results.",
    parameters: [{ name: "query", type: "string", description: "Search query", required: true }],
    code: "async def web_search(query: str) -> list[dict]:\n    return await provider.search(query)",
    createdAt: ago(5000),
  },
  {
    id: "skill_summarise", name: "Summarise", slug: "summarise",
    description: "Condense a passage to its key points.",
    parameters: [
      { name: "text", type: "string", description: "Text to summarise", required: true },
      { name: "max_words", type: "number", description: "Word budget", required: false },
    ],
    code: "async def summarise(text: str, max_words: int = 120) -> str:\n    return await model.summarise(text, max_words)",
    createdAt: ago(4000),
  },
];

let DEPLOYMENTS: Deployment[] = [
  { id: "dep_1", agentId: "agt_orchestrator", agentName: "Orchestrator", environment: "production", status: "live", version: "v1.4.2", url: "https://orchestrator.sporos.run", createdAt: ago(120) },
  { id: "dep_2", agentId: "agt_scribe", agentName: "Scribe", environment: "staging", status: "building", version: "v0.9.0", createdAt: ago(8) },
  { id: "dep_3", agentId: "agt_orchestrator", agentName: "Orchestrator", environment: "production", status: "stopped", version: "v1.4.1", createdAt: ago(7200) },
];

let GATEWAYS: Gateway[] = [
  { id: "gw_openai", name: "OpenAI Primary", provider: "openai", models: ["gpt-4o", "gpt-4o-mini"], active: true, createdAt: ago(9000) },
  { id: "gw_anthropic", name: "Anthropic", provider: "anthropic", models: ["claude-3-5-sonnet", "claude-3-5-haiku"], active: true, createdAt: ago(8000) },
];

export const stats = (): DashboardStats => ({
  agents: AGENTS.length,
  deployments: DEPLOYMENTS.length,
  skills: SKILLS.length,
  gateways: GATEWAYS.length,
  liveDeployments: DEPLOYMENTS.filter((d) => d.status === "live").length,
  callsToday: 18243,
  successRate: 0.984,
  series: [
    { label: "Mon", value: 1200 }, { label: "Tue", value: 2100 }, { label: "Wed", value: 1800 },
    { label: "Thu", value: 2600 }, { label: "Fri", value: 3200 }, { label: "Sat", value: 2400 },
    { label: "Sun", value: 2943 },
  ],
});

export const activity = (): ActivityItem[] => [
  { id: rid(), kind: "deployment", message: "Orchestrator v1.4.2 went live in production", at: ago(120) },
  { id: rid(), kind: "agent", message: "Sentinel created as draft", at: ago(20) },
  { id: rid(), kind: "skill", message: "Summarise skill regenerated", at: ago(300) },
  { id: rid(), kind: "gateway", message: "Anthropic gateway health check passed", at: ago(45) },
];

export const agents = () => structuredClone(AGENTS);
export const agent = (id: string) => {
  const a = AGENTS.find((x) => x.id === id);
  if (!a) throw new Error("Agent not found");
  return structuredClone(a);
};
export const createAgent = (input: CreateAgentInput): Agent => {
  const a: Agent = {
    id: `agt_${rid()}`, slug: slugify(input.name), status: "ready",
    createdAt: now(), updatedAt: now(), ...input,
  };
  AGENTS = [a, ...AGENTS];
  return structuredClone(a);
};

export const skills = () => structuredClone(SKILLS);
export const createSkill = (input: CreateSkillInput): Skill => {
  const params = input.parameters.map((p) => p.name).join(", ");
  const s: Skill = {
    id: `skill_${rid()}`, slug: slugify(input.name), createdAt: now(),
    code: `async def ${slugify(input.name).replace(/-/g, "_")}(${params}):\n    """${input.description}"""\n    raise NotImplementedError`,
    ...input,
  };
  SKILLS = [s, ...SKILLS];
  return structuredClone(s);
};

export const deployments = () => structuredClone(DEPLOYMENTS);
export const createDeployment = (input: CreateDeploymentInput): Deployment => {
  const a = AGENTS.find((x) => x.id === input.agentId);
  const d: Deployment = {
    id: `dep_${rid()}`, agentId: input.agentId, agentName: a?.name ?? "Agent",
    environment: input.environment, status: "queued", version: "v1.0.0", createdAt: now(),
  };
  DEPLOYMENTS = [d, ...DEPLOYMENTS];
  return structuredClone(d);
};

export const gateways = () => structuredClone(GATEWAYS);
export const createGateway = (input: CreateGatewayInput): Gateway => {
  const g: Gateway = {
    id: `gw_${rid()}`, name: input.name, provider: input.provider,
    baseUrl: input.baseUrl, models: input.models, active: true, createdAt: now(),
  };
  GATEWAYS = [g, ...GATEWAYS];
  return structuredClone(g);
};

export const mcp = (query: string): McpRecommendation[] => {
  const base: McpRecommendation[] = [
    { id: "mcp_fs", name: "Filesystem", description: "Read and write files within a sandboxed root.", category: "Storage", url: "https://mcp.dev/filesystem", score: 0.94, tools: 7, verified: true },
    { id: "mcp_gh", name: "GitHub", description: "Issues, PRs and repository operations.", category: "Dev", url: "https://mcp.dev/github", score: 0.9, tools: 21, verified: true },
    { id: "mcp_pg", name: "Postgres", description: "Query and introspect Postgres databases.", category: "Data", url: "https://mcp.dev/postgres", score: 0.88, tools: 9, verified: true },
    { id: "mcp_slack", name: "Slack", description: "Post messages and read channels.", category: "Comms", url: "https://mcp.dev/slack", score: 0.82, tools: 12, verified: false },
    { id: "mcp_web", name: "Web Fetch", description: "Fetch and parse web pages.", category: "Web", url: "https://mcp.dev/web-fetch", score: 0.8, tools: 4, verified: true },
  ];
  const q = query.trim().toLowerCase();
  if (!q) return base;
  return base
    .map((m) => ({ ...m, score: m.score - (m.name.toLowerCase().includes(q) || m.description.toLowerCase().includes(q) ? 0 : 0.3) }))
    .sort((a, b) => b.score - a.score);
};

const TEMPLATES: Template[] = [
  { id: "tpl_support", name: "Support Triage", description: "Classifies tickets and drafts replies.", category: "Customer", tags: ["support", "classification"], popularity: 92, agentPreset: { name: "Support Triage", description: "Triage and respond to tickets", model: "gpt-4o", temperature: 0.3 } },
  { id: "tpl_research", name: "Research Analyst", description: "Gathers sources and synthesises briefings.", category: "Knowledge", tags: ["research", "web"], popularity: 88, agentPreset: { name: "Research Analyst", description: "Synthesise research briefings", model: "claude-3-5-sonnet", temperature: 0.5 } },
  { id: "tpl_devops", name: "DevOps Sentinel", description: "Watches infra signals and proposes fixes.", category: "Engineering", tags: ["ops", "monitoring"], popularity: 79, agentPreset: { name: "DevOps Sentinel", description: "Monitor infrastructure", model: "gpt-4o-mini", temperature: 0.1 } },
  { id: "tpl_sales", name: "Sales Outreach", description: "Personalises cold outreach at scale.", category: "Growth", tags: ["sales", "writing"], popularity: 74, agentPreset: { name: "Sales Outreach", description: "Personalised outreach", model: "gpt-4o", temperature: 0.7 } },
  { id: "tpl_data", name: "Data Wrangler", description: "Cleans, joins and profiles datasets.", category: "Data", tags: ["data", "sql"], popularity: 71, agentPreset: { name: "Data Wrangler", description: "Clean and profile data", model: "gpt-4o", temperature: 0.2 } },
  { id: "tpl_legal", name: "Contract Reviewer", description: "Flags risky clauses in agreements.", category: "Legal", tags: ["legal", "review"], popularity: 65, agentPreset: { name: "Contract Reviewer", description: "Review contracts", model: "claude-3-5-sonnet", temperature: 0.2 } },
];

export const templates = () => structuredClone(TEMPLATES);
export const template = (id: string) => {
  const t = TEMPLATES.find((x) => x.id === id);
  if (!t) throw new Error("Template not found");
  return structuredClone(t);
};
