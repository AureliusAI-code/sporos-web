/**
 * Hermes route table. The other SWAP POINT alongside types.ts.
 * Adjust these paths to match the real OpenAPI spec; nothing else changes.
 */
export const ROUTES = {
  stats: "/v1/dashboard/stats",
  activity: "/v1/dashboard/activity",

  agents: "/v1/agents",
  agent: (id: string) => `/v1/agents/${id}`,

  skills: "/v1/skills",
  skill: (id: string) => `/v1/skills/${id}`,
  generateSkill: "/v1/skills/generate",

  deployments: "/v1/deployments",
  deployment: (id: string) => `/v1/deployments/${id}`,

  gateways: "/v1/gateways",
  gateway: (id: string) => `/v1/gateways/${id}`,

  mcpRecommend: "/v1/mcp/recommend",
  mcpSearch: "/v1/mcp/search",

  templates: "/v1/templates",
  template: (id: string) => `/v1/templates/${id}`,
} as const;
