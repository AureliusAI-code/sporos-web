/**
 * Sporos ⇄ Hermes API types.
 *
 * ──────────────────────────────────────────────────────────────────────────
 * SWAP POINT: This file is the single source of truth for the Hermes contract.
 * When the real OpenAPI JSON is available, regenerate these interfaces (e.g.
 * `npx openapi-typescript hermes.json -o src/lib/api/types.ts`) or hand-edit
 * to match. The rest of the app consumes only these types + the route table
 * in `routes.ts`, so updating those two files re-points everything.
 * ──────────────────────────────────────────────────────────────────────────
 */

export type ID = string;

export type AgentStatus = "draft" | "ready" | "deployed" | "error";
export type DeploymentStatus = "queued" | "building" | "live" | "failed" | "stopped";
export type Environment = "development" | "staging" | "production";

export interface MemoryConfig {
  type: "ephemeral" | "buffer" | "vector";
  window: number; // turns retained for buffer
  vectorStore?: string; // provider id for vector memory
  embedModel?: string;
}

export interface Agent {
  id: ID;
  name: string;
  slug: string;
  description: string;
  instructions: string; // natural-language system prompt
  model: string;
  temperature: number;
  status: AgentStatus;
  tools: string[]; // skill/tool ids
  memory: MemoryConfig;
  gatewayId?: ID;
  createdAt: string;
  updatedAt: string;
}

export interface CreateAgentInput {
  name: string;
  description: string;
  instructions: string;
  model: string;
  temperature: number;
  tools: string[];
  memory: MemoryConfig;
  gatewayId?: ID;
}

export interface SkillParameter {
  name: string;
  type: "string" | "number" | "boolean" | "object" | "array";
  description: string;
  required: boolean;
}

export interface Skill {
  id: ID;
  name: string;
  slug: string;
  description: string;
  parameters: SkillParameter[];
  code?: string; // generated implementation preview
  createdAt: string;
}

export interface CreateSkillInput {
  name: string;
  description: string;
  parameters: SkillParameter[];
}

export interface Deployment {
  id: ID;
  agentId: ID;
  agentName: string;
  environment: Environment;
  status: DeploymentStatus;
  version: string;
  url?: string;
  createdAt: string;
}

export interface CreateDeploymentInput {
  agentId: ID;
  environment: Environment;
}

export type GatewayProvider =
  | "openai"
  | "anthropic"
  | "azure-openai"
  | "google-vertex"
  | "mistral"
  | "groq"
  | "ollama";

export interface Gateway {
  id: ID;
  name: string;
  provider: GatewayProvider;
  baseUrl?: string;
  models: string[];
  active: boolean;
  createdAt: string;
}

export interface CreateGatewayInput {
  name: string;
  provider: GatewayProvider;
  baseUrl?: string;
  apiKey: string;
  models: string[];
}

export interface McpRecommendation {
  id: ID;
  name: string;
  description: string;
  category: string;
  url: string;
  score: number; // 0..1 relevance
  tools: number; // count of tools exposed
  verified: boolean;
}

export interface Template {
  id: ID;
  name: string;
  description: string;
  category: string;
  tags: string[];
  agentPreset: Partial<CreateAgentInput>;
  popularity: number;
}

export interface DashboardStats {
  agents: number;
  deployments: number;
  skills: number;
  gateways: number;
  liveDeployments: number;
  callsToday: number;
  successRate: number; // 0..1
  series: { label: string; value: number }[];
}

export interface ActivityItem {
  id: ID;
  kind: "agent" | "skill" | "deployment" | "gateway";
  message: string;
  at: string;
}

export interface ApiError {
  detail: string;
  status: number;
}
