"use client";

import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { api, HermesError } from "../api/client";
import type {
  CreateAgentInput, CreateSkillInput, CreateDeploymentInput, CreateGatewayInput,
} from "../api/types";

const keys = {
  stats: ["stats"] as const,
  activity: ["activity"] as const,
  agents: ["agents"] as const,
  agent: (id: string) => ["agents", id] as const,
  skills: ["skills"] as const,
  deployments: ["deployments"] as const,
  gateways: ["gateways"] as const,
  templates: ["templates"] as const,
  template: (id: string) => ["templates", id] as const,
  mcp: (q: string) => ["mcp", q] as const,
};

function errMsg(e: unknown) {
  if (e instanceof HermesError) return `${e.message} (${e.status})`;
  return e instanceof Error ? e.message : "Unexpected error";
}

/* ── Queries ──────────────────────────────────────────────────────────── */
export const useStats = () => useQuery({ queryKey: keys.stats, queryFn: api.getStats });
export const useActivity = () => useQuery({ queryKey: keys.activity, queryFn: api.getActivity });
export const useAgents = () => useQuery({ queryKey: keys.agents, queryFn: api.listAgents });
export const useAgent = (id: string) =>
  useQuery({ queryKey: keys.agent(id), queryFn: () => api.getAgent(id), enabled: !!id });
export const useSkills = () => useQuery({ queryKey: keys.skills, queryFn: api.listSkills });
export const useDeployments = () => useQuery({ queryKey: keys.deployments, queryFn: api.listDeployments });
export const useGateways = () => useQuery({ queryKey: keys.gateways, queryFn: api.listGateways });
export const useTemplates = () => useQuery({ queryKey: keys.templates, queryFn: api.listTemplates });
export const useTemplate = (id: string) =>
  useQuery({ queryKey: keys.template(id), queryFn: () => api.getTemplate(id), enabled: !!id });

/* ── Mutations ────────────────────────────────────────────────────────── */
export function useCreateAgent() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (input: CreateAgentInput) => api.createAgent(input),
    onSuccess: (a) => {
      qc.invalidateQueries({ queryKey: keys.agents });
      qc.invalidateQueries({ queryKey: keys.stats });
      toast.success(`Agent “${a.name}” forged`, { description: "Ready to deploy." });
    },
    onError: (e) => toast.error("Could not create agent", { description: errMsg(e) }),
  });
}

export function useCreateSkill() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (input: CreateSkillInput) => api.generateSkill(input),
    onSuccess: (s) => {
      qc.invalidateQueries({ queryKey: keys.skills });
      toast.success(`Skill “${s.name}” generated`);
    },
    onError: (e) => toast.error("Could not generate skill", { description: errMsg(e) }),
  });
}

export function useCreateDeployment() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (input: CreateDeploymentInput) => api.createDeployment(input),
    onSuccess: (d) => {
      qc.invalidateQueries({ queryKey: keys.deployments });
      qc.invalidateQueries({ queryKey: keys.stats });
      toast.success(`Deploying to ${d.environment}`, { description: `Version ${d.version}` });
    },
    onError: (e) => toast.error("Deployment failed", { description: errMsg(e) }),
  });
}

export function useCreateGateway() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (input: CreateGatewayInput) => api.createGateway(input),
    onSuccess: (g) => {
      qc.invalidateQueries({ queryKey: keys.gateways });
      toast.success(`Gateway “${g.name}” connected`);
    },
    onError: (e) => toast.error("Could not connect gateway", { description: errMsg(e) }),
  });
}

export function useRecommendMcp() {
  return useMutation({
    mutationFn: (query: string) => api.recommendMcp(query),
    onError: (e) => toast.error("Recommendation failed", { description: errMsg(e) }),
  });
}
