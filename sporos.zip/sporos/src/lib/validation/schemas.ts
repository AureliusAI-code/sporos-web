import { z } from "zod";

export const memorySchema = z.object({
  type: z.enum(["ephemeral", "buffer", "vector"]),
  window: z.coerce.number().int().min(0).max(200),
  vectorStore: z.string().optional(),
  embedModel: z.string().optional(),
});

export const agentSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters").max(60),
  description: z.string().min(5, "Add a short description").max(280),
  instructions: z.string().min(10, "Describe what the agent should do"),
  model: z.string().min(1, "Select a model"),
  temperature: z.coerce.number().min(0).max(2),
  tools: z.array(z.string()).default([]),
  memory: memorySchema,
  gatewayId: z.string().optional(),
});
export type AgentForm = z.infer<typeof agentSchema>;

export const skillParamSchema = z.object({
  name: z.string().min(1, "Required").regex(/^[a-z_][a-z0-9_]*$/i, "Use a valid identifier"),
  type: z.enum(["string", "number", "boolean", "object", "array"]),
  description: z.string().min(1, "Required"),
  required: z.boolean().default(true),
});

export const skillSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters").max(60),
  description: z.string().min(10, "Describe what the skill does"),
  parameters: z.array(skillParamSchema).default([]),
});
export type SkillForm = z.infer<typeof skillSchema>;

export const deploymentSchema = z.object({
  agentId: z.string().min(1, "Select an agent"),
  environment: z.enum(["development", "staging", "production"]),
});
export type DeploymentForm = z.infer<typeof deploymentSchema>;

export const gatewaySchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters").max(60),
  provider: z.enum(["openai", "anthropic", "azure-openai", "google-vertex", "mistral", "groq", "ollama"]),
  baseUrl: z.string().url("Enter a valid URL").optional().or(z.literal("")),
  apiKey: z.string().min(1, "API key is required"),
  models: z.array(z.string()).min(1, "Add at least one model"),
});
export type GatewayForm = z.infer<typeof gatewaySchema>;
